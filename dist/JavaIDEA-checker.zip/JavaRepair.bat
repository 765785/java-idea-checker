@echo off & title Java Environment Checker
if not exist "%~dp0JavaCheck.ps1" (powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0JavaRepair.ps1" -MissingChecker) else powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0JavaRepair.ps1"
pause
