﻿# Java IDEA Windows Self-Check Tool
# https://github.com/765785/java-idea-checker
# MIT License. This readable script collects local Java/IDEA evidence and may repair
# only the current user's JAVA_HOME and Path after backup. It does not remove files,
# change CLASSPATH, alter IDEA login or activate any license.
# Security software can still review scripts with these legitimate system actions.

param([string]$OutputDirectory)
$EduDomains=@('dnui.edu.cn')

if (!$PSVersionTable -or [int]$PSVersionTable.PSVersion.Major -lt 3) {
  Write-Host '你的 Windows 版本较旧，请升级 PowerShell 或使用页面上的手动检查步骤。'
  exit 2
}
if ($env:OS -ne 'Windows_NT') {
  Write-Host '本工具只支持 Windows 桌面系统，请在要检测的 Windows 电脑上运行。'
  exit 3
}
try { $Host.UI.RawUI.WindowTitle='Java 环境自检工具' } catch {}

$script:Issues = New-Object 'System.Collections.Generic.List[object]'
function Protect-Text([string]$Text) {
  if ($env:USERPROFILE) { $Text = [regex]::Replace($Text, [regex]::Escape($env:USERPROFILE), '%USERPROFILE%', 'IgnoreCase') }
  return [regex]::Replace($Text, '[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})', { param($m) $m.Value.Substring(0,1) + '***@' + $m.Groups[1].Value })
}
function Record-Issue([string]$Field, $Problem) {
  $message = Protect-Text ([string]$Problem)
  $script:Issues.Add([pscustomobject]@{ field=$Field; error=$message })
  if ($script:LogFile) { try { Add-Content -LiteralPath $script:LogFile -Value ($Field + ': ' + $message) -Encoding UTF8 -ErrorAction Stop } catch {} }
}
function Invoke-Section([string]$Field,[scriptblock]$Action,$Fallback) {
  try { return & $Action } catch { Record-Issue $Field $_; return $Fallback }
}
function Invoke-Captured([string]$File, [string[]]$Arguments) {
  $oldEncoding = $null; $oldOutput = $OutputEncoding; $oldPreference = $ErrorActionPreference
  try {
    try { $oldEncoding = [Console]::OutputEncoding; [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false); $OutputEncoding = [Console]::OutputEncoding } catch { Record-Issue 'encoding' $_ }
    $ErrorActionPreference = 'Continue'
    $global:LASTEXITCODE = $null
    $lines = @(& $File @Arguments 2>&1)
    $code = $LASTEXITCODE
    if ($null -eq $code) { $code = -1 }
    return [pscustomobject]@{ output=(($lines | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine); exitCode=$code }
  } catch { Record-Issue $File $_; return [pscustomobject]@{ output=[string]$_; exitCode=-1 } }
  finally { $ErrorActionPreference=$oldPreference; $OutputEncoding=$oldOutput; if ($oldEncoding) { try { [Console]::OutputEncoding=$oldEncoding } catch { Record-Issue 'encoding.restore' $_ } } }
}
function Initialize-Native {
  if ('JavaCheckNative' -as [type]) { return }
  Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class JavaCheckNative {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern uint GetLongPathName(string path, StringBuilder buffer, uint size);
 [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint msg, UIntPtr wp, string lp, uint flags, uint timeout, out UIntPtr result);
}
'@ -ErrorAction Stop
}
function Normalize-Directory([string]$Value, [switch]$StripBin) {
  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  try {
    $v=$Value.Trim(); if (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'"))) { $v=$v.Substring(1,$v.Length-2) }
    $v=[Environment]::ExpandEnvironmentVariables($v.Replace('/','\'))
    if ($v -notmatch '^(?:[a-zA-Z]:\\|\\\\)') { throw '路径不是绝对目录' }
    $v=[IO.Path]::GetFullPath($v)
    if ($StripBin) { $v=$v.TrimEnd('\'); if ($v -match '\\bin$') { $v=Split-Path -Parent $v } }
    if (Test-Path -LiteralPath $v) {
      Initialize-Native
      $buffer=New-Object Text.StringBuilder 32768
      $length=[JavaCheckNative]::GetLongPathName($v,$buffer,32768)
      if ($length -eq 0 -or $length -ge 32768) { throw '无法确认目录的长路径，不能比较短名' }
      $v=$buffer.ToString()
    }
    if ($v.Length -gt ([IO.Path]::GetPathRoot($v)).Length) { $v=$v.TrimEnd('\') }
    return $v.ToLowerInvariant()
  } catch { Record-Issue 'path.normalize' $_; return $null }
}
function Is-Forwarder([string]$Path) { return $Path -match '(?i)\\(?:System32|SysWOW64|WindowsApps)(?:\\|$)|\\Common Files\\Oracle\\Java\\javapath(?:\\|$)' }
function Get-Major([string]$Text) { if ($Text -match '(?i)(?:version|版本|javac|openjdk)\s+"?(?:1\.)?(\d+)') { return [int]$Matches[1] }; return 0 }
function Read-EnvironmentValue([string]$Scope,[string]$Name) {
  $key=$null
  try {
    if ($Scope -eq 'User') { $key=[Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment') } else { $key=[Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\Session Manager\Environment') }
    $exists=$key -and ($key.GetValueNames() -contains $Name)
    if (!$exists) { return [pscustomobject]@{ exists=$false; value=$null; kind=$null; error=$null } }
    return [pscustomobject]@{ exists=$true; value=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames); kind=$key.GetValueKind($Name).ToString(); error=$null }
  } catch { Record-Issue ('registry.'+$Scope+'.'+$Name) $_; return [pscustomobject]@{ exists=$null; value=$null; kind=$null; error=[string]$_ } }
  finally { if ($key) { $key.Dispose() } }
}
function Get-EnvironmentSnapshot {
  return [pscustomobject]@{ user=[pscustomobject]@{ JAVA_HOME=(Read-EnvironmentValue User JAVA_HOME); Path=(Read-EnvironmentValue User Path) }; machine=[pscustomobject]@{ JAVA_HOME=(Read-EnvironmentValue Machine JAVA_HOME); Path=(Read-EnvironmentValue Machine Path) } }
}
function Get-EffectiveHome($Snapshot) { if (![string]::IsNullOrWhiteSpace($Snapshot.user.JAVA_HOME.value)) { return [string]$Snapshot.user.JAVA_HOME.value }; return [string]$Snapshot.machine.JAVA_HOME.value }
function Get-Where([string]$Name) { $r=Invoke-Captured (Join-Path $env:SystemRoot 'System32\where.exe') @($Name); if ($r.exitCode -eq 0) { return @($r.output -split '\r?\n' | Where-Object { $_ -match '^[a-zA-Z]:\\' }) }; return @() }
function Probe-Jdk([string]$Directory,[string]$Source) {
  $path=Normalize-Directory $Directory -StripBin
  $result=[ordered]@{ path=$path; source=$Source; valid=$false; major=0; version=''; error=$null }
  if (!$path) { if (![string]::IsNullOrWhiteSpace($Directory)) { $result.error='目录无法归一化' }; return [pscustomobject]$result }
  try {
    if (!(Test-Path -LiteralPath (Join-Path $path 'bin\java.exe')) -or !(Test-Path -LiteralPath (Join-Path $path 'bin\javac.exe'))) { return [pscustomobject]$result }
    $j=Invoke-Captured (Join-Path $path 'bin\java.exe') @('-version'); $c=Invoke-Captured (Join-Path $path 'bin\javac.exe') @('-version')
    $result.major=Get-Major $c.output; $result.version=$c.output
    $result.valid=$j.exitCode -eq 0 -and $c.exitCode -eq 0 -and $result.major -gt 0 -and (Get-Major $j.output) -eq $result.major
  } catch { $result.error=[string]$_; Record-Issue 'jdk.probe' $_ }
  return [pscustomobject]$result
}
function Get-UninstallEntries {
  foreach ($rootKey in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
    try { if (Test-Path $rootKey) { Get-ItemProperty ($rootKey+'\*') -ErrorAction Stop | Where-Object { $_.DisplayName -match 'Java|JDK|Temurin|IntelliJ|JetBrains' } } } catch { Record-Issue 'uninstall' $_ }
  }
}
function Find-Jdks($Snapshot,$WhereJavac) {
  $locations=New-Object 'System.Collections.Generic.List[object]'
  $effective=Get-EffectiveHome $Snapshot
  if ($effective) { $locations.Add(@{path=$effective;source='JAVA_HOME'}) }
  foreach ($value in @($Snapshot.user.JAVA_HOME.value,$Snapshot.machine.JAVA_HOME.value)) { if ($value) { $locations.Add(@{path=$value;source='registry-home'}); if ($value -match '\\jre[\\/]?$') { $locations.Add(@{path=(Split-Path -Parent $value.TrimEnd('\'));source='JAVA_HOME.parent'}) } } }
  foreach ($item in $WhereJavac) { if (!(Is-Forwarder $item)) { $locations.Add(@{path=(Split-Path -Parent (Split-Path -Parent $item));source='where'}) } }
  foreach ($entry in @(Get-UninstallEntries)) { if ($entry.DisplayName -match 'JDK|Java.*Development' -and $entry.InstallLocation) { $locations.Add(@{path=$entry.InstallLocation;source='registry'}) } }
  foreach ($base in @((Join-Path $env:USERPROFILE '.jdks'),(Join-Path $env:ProgramFiles 'Java'),(Join-Path $env:ProgramFiles 'Eclipse Adoptium'),(Join-Path $env:ProgramFiles 'Microsoft'), 'C:\Java','D:\Java','C:\JavaDev','D:\JavaDev')) {
    try { if (Test-Path -LiteralPath $base) { foreach ($dir in @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction Stop)) { $source='directory'; if ($base -like '*.jdks') { $source='.jdks' }; $locations.Add(@{path=$dir.FullName;source=$source}) } } } catch { Record-Issue 'jdk.directories' $_ }
  }
  $seen=@{}; $found=@()
  foreach ($location in $locations) { $key=Normalize-Directory $location.path -StripBin; if ($key -and !$seen.ContainsKey($key)) { $seen[$key]=$true; $found+=Probe-Jdk $key $location.source } }
  return @($found)
}
function Select-Jdk($Candidates) {
  $valid=@($Candidates | Where-Object { $_.valid })
  foreach ($source in @('JAVA_HOME','where','.jdks')) { $items=@($valid | Where-Object { $_.source -eq $source } | Sort-Object @{Expression='major';Descending=$true},path); if ($items.Count) { return $items[0] } }
  return $valid | Sort-Object @{Expression='major';Descending=$true},path | Select-Object -First 1
}
function Runtime-Evidence($Settings,$WhereJavac) {
  $runtime=$null; $compiler=$null
  if ($Settings.output -match '(?m)^\s*java\.home\s*=\s*(.+)$') {
    $runtime=Normalize-Directory $Matches[1].Trim()
    if ($runtime -match '\\jre$') { $parent=Probe-Jdk (Split-Path -Parent $runtime) 'runtime'; if ($parent.valid) { $runtime=$parent.path } }
  }
  foreach ($path in $WhereJavac) { if (!(Is-Forwarder $path)) { $compiler=Normalize-Directory (Split-Path -Parent (Split-Path -Parent $path)); break } }
  return [pscustomobject]@{ runtime=$runtime; compiler=$compiler }
}
function Compare-Path($A,$B) { if (!$A -or !$B) { return $null }; return $A -eq $B }

function Normalize-EduDomain([string]$Domain) {
  if ([string]::IsNullOrWhiteSpace($Domain)) { return '' }
  return $Domain.Trim().TrimEnd('.').ToLowerInvariant()
}
function Test-EduDomain([string]$Domain) {
  $candidate=Normalize-EduDomain $Domain
  foreach ($allowed in @($EduDomains)) { if ($candidate -eq (Normalize-EduDomain ([string]$allowed))) { return $true } }
  return $false
}
function Get-EvidencePath([string]$ScanRoot,[string]$FullName) {
  $relative=$FullName
  try { if ($FullName.StartsWith($ScanRoot,[StringComparison]::OrdinalIgnoreCase)) { $relative=$FullName.Substring($ScanRoot.Length).TrimStart('\') } } catch {}
  return Protect-Text (($ScanRoot.Split('\')[-1]+'\'+$relative).Trim('\'))
}
function Test-AccountEvidencePath([string]$RelativePath) {
  return $RelativePath -match '(?i)(account|licen|subscription|permanent)|(^|\\)options\\other\.xml$'
}
function Add-EmailEvidence($Map,[string]$Email,[string]$RelativePath,[string]$Kind,[bool]$AccountRelated) {
  $key=$Email.Trim().ToLowerInvariant().TrimEnd('.')
  if (!$key) { return }
  if (!$Map.ContainsKey($key)) {
    $Map[$key]=[pscustomobject]@{kind=$Kind;email=(Protect-Text $Email);paths=@($RelativePath);accountRelated=$AccountRelated}
    return
  }
  $item=$Map[$key]
  if ($Kind -eq 'WHITELIST_EMAIL') { $item.kind=$Kind }
  $item.accountRelated=($item.accountRelated -or $AccountRelated)
  if (@($item.paths).Count -lt 5 -and !(@($item.paths) -contains $RelativePath)) { $item.paths+=@($RelativePath) }
}
function Add-DomainEvidence($Map,[string]$Domain,[string]$RelativePath,[bool]$AccountRelated) {
  $key=Normalize-EduDomain $Domain
  if (!$key) { return }
  if (!$Map.ContainsKey($key)) {
    $Map[$key]=[pscustomobject]@{kind='DOMAIN_LITERAL';email=('***@'+$key);paths=@($RelativePath);accountRelated=$AccountRelated}
    return
  }
  $item=$Map[$key]; $item.accountRelated=($item.accountRelated -or $AccountRelated)
  if (@($item.paths).Count -lt 5 -and !(@($item.paths) -contains $RelativePath)) { $item.paths+=@($RelativePath) }
}
function Get-CredentialManagerEvidence {
  $entries=New-Object 'System.Collections.Generic.List[string]'
  $cmdkey=Join-Path $env:SystemRoot 'System32\cmdkey.exe'
  if (!(Test-Path -LiteralPath $cmdkey)) { return [pscustomobject]@{status='UNKNOWN';entries=@();errors=@('cmdkey.exe 不可用')} }
  $result=Invoke-Captured $cmdkey @('/list')
  if ($result.exitCode -ne 0) {
    $message=Protect-Text $result.output
    if ($message.Length -gt 300) { $message=$message.Substring(0,300) }
    return [pscustomobject]@{status='UNKNOWN';entries=@();errors=@($message)}
  }
  foreach ($line in @($result.output -split '\r?\n')) {
    if ($line -notmatch '^\s*(?:Target|目标)\s*[:：]\s*(.+)$') { continue }
    $name=$Matches[1].Trim()
    if ($name -match '(?i)JetBrains|IntelliJ|Toolbox') { $entries.Add((Protect-Text $name)) }
  }
  return [pscustomobject]@{status='OK';entries=@($entries.ToArray() | Select-Object -Unique);errors=@()}
}
function Get-EmailEvidence {
  $roots=New-Object 'System.Collections.Generic.List[string]'
  $scanErrors=New-Object 'System.Collections.Generic.List[string]'
  try {
    $jetBrains=Join-Path $env:APPDATA 'JetBrains'
    if (Test-Path -LiteralPath $jetBrains) { foreach ($d in @(Get-ChildItem -LiteralPath $jetBrains -Directory -ErrorAction Stop | Where-Object { $_.Name -match '^(IntelliJIdea|IdeaIC)' })) { $roots.Add($d.FullName) } }
  } catch { $scanErrors.Add((Protect-Text ([string]$_))); Record-Issue 'email.roots' $_ }
  try {
    if (Test-Path -LiteralPath $env:USERPROFILE) { foreach ($d in @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -ErrorAction Stop | Where-Object { $_.Name -match '^\.IntelliJIdea' })) { $config=Join-Path $d.FullName 'config'; if (Test-Path -LiteralPath $config) { $roots.Add($config) } } }
  } catch { $scanErrors.Add((Protect-Text ([string]$_))); Record-Issue 'email.legacyRoots' $_ }
  try { $toolbox=Join-Path $env:LOCALAPPDATA 'JetBrains\Toolbox'; if (Test-Path -LiteralPath $toolbox) { $roots.Add($toolbox) } } catch { $scanErrors.Add((Protect-Text ([string]$_))); Record-Issue 'email.toolboxRoot' $_ }

  $emailMap=@{}; $domainMap=@{}; $xmlEvidence=New-Object 'System.Collections.Generic.List[object]'; $credentialFiles=New-Object 'System.Collections.Generic.List[string]'; $credentialFileSeen=@{}; $seen=@{}; $count=0; $truncated=$false; $unknown=$scanErrors.Count -gt 0
  $domains=@($EduDomains | ForEach-Object { Normalize-EduDomain ([string]$_) } | Where-Object { $_ })
  foreach ($scanRoot in @($roots | Select-Object -Unique)) {
    $stack=New-Object 'System.Collections.Generic.Stack[string]'; $stack.Push($scanRoot)
    while ($stack.Count -gt 0) {
      $dir=$stack.Pop()
      try { $items=@(Get-ChildItem -LiteralPath $dir -Force -ErrorAction Stop | Sort-Object @{Expression={ if ($_.Name -eq 'other.xml') {0} elseif ($_.Name -eq 'options') {1} else {2} }},Name) } catch { $unknown=$true; $scanErrors.Add((Protect-Text ([string]$_))); Record-Issue 'email.readDirectory' $_; continue }
      foreach ($file in $items) {
        if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        if ($file.PSIsContainer) { if ($file.Name -notmatch '(?i)^(log|logs|cache|caches|index|tmp)$') { $stack.Push($file.FullName) }; continue }
        $relative=Get-EvidencePath $scanRoot $file.FullName
        if ($file.Name -match '(?i)(credential|kdbx|keychain|secure|store)') { if (!$credentialFileSeen.ContainsKey($relative)) { $credentialFileSeen[$relative]=$true; $credentialFiles.Add($relative) } }
        if ($file.Extension -notmatch '(?i)^\.(xml|txt|json|properties)$' -or $file.Length -gt 5MB -or $seen.ContainsKey($file.FullName)) { continue }
        if ($count -ge 3000) { $truncated=$true; break }
        $seen[$file.FullName]=$true; $count++
        try { $body=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 -ErrorAction Stop } catch { $unknown=$true; $scanErrors.Add((Protect-Text ([string]$_))); Record-Issue 'email.readFile' $_; continue }
        if ([string]::IsNullOrEmpty($body)) { continue }
        $accountRelated=Test-AccountEvidencePath $relative
        foreach ($domain in $domains) { if ($body -match ('(?i)(?<![\w.-])'+[regex]::Escape($domain)+'(?![\w.-])')) { Add-DomainEvidence $domainMap $domain $relative $accountRelated } }
        foreach ($match in [regex]::Matches([string]$body,'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')) {
          $email=[string]$match.Value; $domain=Normalize-EduDomain ($email.Split('@')[-1]); $kind=$(if (Test-EduDomain $domain) {'WHITELIST_EMAIL'} else {'OTHER_EMAIL'})
          Add-EmailEvidence $emailMap $email $relative $kind $accountRelated
        }
        if ($file.Extension -ieq '.xml') {
          foreach ($line in @($body -split '\r?\n')) {
            if ($line -notmatch '(?i)(account|licen|email|mail|user|PermanentUserId|subscription)') { continue }
            $snippet=Protect-Text $line.Trim(); if ($snippet.Length -gt 300) { $snippet=$snippet.Substring(0,300) }
            if ($snippet -and $xmlEvidence.Count -lt 20) { $xmlEvidence.Add([pscustomobject]@{kind='XML_KEY_LINE';path=$relative;snippet=$snippet;accountRelated=$accountRelated}) }
          }
        }
      }
      if ($truncated) { break }
    }
    if ($truncated) { break }
  }
  $credentials=Get-CredentialManagerEvidence
  $credentialEntries=@(); foreach ($entry in @($credentials.entries)) { $credentialEntries+=@(Protect-Text ([string]$entry)) }
  $credentialErrors=@(); foreach ($entryError in @($credentials.errors)) { $credentialErrors+=@(Protect-Text ([string]$entryError)) }
  $credentials=[pscustomobject]@{status=$credentials.status;entries=@($credentialEntries | Select-Object -Unique);errors=@($credentialErrors | Select-Object -Unique)}
  if ($credentials.status -eq 'UNKNOWN') { $unknown=$true; foreach ($error in @($credentials.errors)) { $scanErrors.Add((Protect-Text $error)) } }
  $domainList=New-Object 'System.Collections.Generic.List[object]'; foreach ($key in @($domainMap.Keys)) { $domainList.Add($domainMap[$key]) }
  $emailList=New-Object 'System.Collections.Generic.List[object]'; foreach ($key in @($emailMap.Keys)) { $emailList.Add($emailMap[$key]) }
  return [pscustomobject]@{status=$(if($unknown){'UNKNOWN'}else{'OK'});domains=@($domains);domainEvidence=@($domainList.ToArray());emailEvidence=@($emailList.ToArray());xmlEvidence=@($xmlEvidence.ToArray());credentialManager=$credentials;credentialFiles=@($credentialFiles.ToArray() | Select-Object -First 20);configPresent=(@($roots | Select-Object -Unique).Count -gt 0);scanned=$count;truncated=$truncated;errors=@($scanErrors.ToArray() | Select-Object -Unique)}
}
function Get-DirectoryEvidence {
  foreach ($dir in @((Join-Path $env:APPDATA 'JetBrains'),(Join-Path $env:LOCALAPPDATA 'JetBrains'),(Join-Path $env:USERPROFILE '.jdks'),(Join-Path $env:LOCALAPPDATA 'JetBrains\Toolbox'))) {
    try { $exists=Test-Path -LiteralPath $dir; $children=@(); if ($exists) { $children=@(Get-ChildItem -LiteralPath $dir -Directory -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ name=$_.Name; modified=$_.LastWriteTimeUtc.ToString('o') } }) }; [pscustomobject]@{ path=$dir; exists=$exists; children=$children } } catch { Record-Issue 'directories' $_; [pscustomobject]@{path=$dir;exists=$null;children=@()} }
  }
}
function Get-Idea {
  $found=@(); $paths=@('C:\idea\IntelliJ IDEA 2026.2.2'); $seen=@{}
  foreach ($e in @(Get-UninstallEntries | Where-Object { $_.DisplayName -match 'IntelliJ' })) { if ($e.InstallLocation) { $paths+=$e.InstallLocation; if (Test-Path -LiteralPath (Join-Path $e.InstallLocation 'bin\idea64.exe')) { $found+=[pscustomobject]@{path=$e.InstallLocation;version=$e.DisplayVersion;name=$e.DisplayName}; $seen[$e.InstallLocation.TrimEnd('\').ToLowerInvariant()]=$true } } }
  foreach ($base in @((Join-Path $env:ProgramFiles 'JetBrains'),'C:\idea',(Join-Path $env:LOCALAPPDATA 'Programs'),(Join-Path $env:LOCALAPPDATA 'JetBrains\Toolbox\apps'))) {
    try { if (Test-Path -LiteralPath $base) { $queue=New-Object 'System.Collections.Generic.Queue[object]'; $queue.Enqueue(@{path=$base;depth=0}); while ($queue.Count) { $node=$queue.Dequeue(); $paths+=$node.path; if ($node.depth -lt 4) { foreach ($child in @(Get-ChildItem -LiteralPath $node.path -Directory -ErrorAction Stop)) { if (!($child.Attributes -band [IO.FileAttributes]::ReparsePoint)) { $queue.Enqueue(@{path=$child.FullName;depth=($node.depth+1)}) } } } } } } catch { Record-Issue 'idea.directories' $_ }
  }
  foreach ($dir in $paths) { try { $key=$dir.TrimEnd('\').ToLowerInvariant(); $exe=Join-Path $dir 'bin\idea64.exe'; if (!$seen[$key] -and (Test-Path -LiteralPath $exe)) { $seen[$key]=$true; $version=(Get-Item -LiteralPath $exe).VersionInfo.ProductVersion; $info=Join-Path $dir 'product-info.json'; if (Test-Path -LiteralPath $info) { $version=(Get-Content -LiteralPath $info -Raw -Encoding UTF8 | ConvertFrom-Json).version }; $found+=[pscustomobject]@{path=$dir;version=$version;name='IntelliJ IDEA'} } } catch { Record-Issue 'idea.probe' $_ } }
  return [pscustomobject]@{ installations=@($found | Sort-Object @{Expression={ try { [version]([regex]::Match([string]$_.version,'\d+(?:\.\d+){0,3}').Value) } catch { [version]'0.0' } };Descending=$true}) }
}
function Get-Trace {
  foreach ($scope in @('User','Machine')) { try { $all=[Environment]::GetEnvironmentVariables($scope); foreach ($name in $all.Keys) { if ($name -match 'jetbra|pojie|_VM_OPTIONS$') { [pscustomobject]@{scope=$scope;name=$name;matched=($name -match 'jetbra|pojie' -or [string]$all[$name] -match 'jetbra|pojie')} } } } catch { Record-Issue 'trace' $_ } }
}
function Collect-Result {
  Write-Host '【1/4】正在检查 JAVA_HOME 和 Path...'
  $snapshot=Get-EnvironmentSnapshot; $effective=Get-EffectiveHome $snapshot
  $whereJava=@(Get-Where java); $whereJavac=@(Get-Where javac)
  Write-Host '【2/4】正在验证 java 与 javac...'
  $j=Invoke-Captured java @('-version'); $c=Invoke-Captured javac @('-version'); $settings=Invoke-Captured java @('-XshowSettings:properties','-version')
  $candidates=@(Find-Jdks $snapshot $whereJavac); $probe=Probe-Jdk $effective 'JAVA_HOME'; $evidence=Runtime-Evidence $settings $whereJavac
  $includes=$false; $rawPaths=@(); foreach ($value in @($snapshot.machine.Path.value,$snapshot.user.Path.value,$env:Path)) { foreach ($entry in ([string]$value -split ';')) { if ($entry -match 'java|jdk|jetbrains') { $rawPaths+=$entry }; $expanded=$entry -replace '(?i)%JAVA_HOME%',([string]$probe.path).Replace('$','$$'); if ($probe.path -and (Normalize-Directory $expanded) -eq ($probe.path+'\bin')) { $includes=$true } } }
  $diskUnavailable=$false; if ($effective -match '^([a-zA-Z]:)') { $diskUnavailable=!(Test-Path ($Matches[1]+'\')) }
  Write-Host '【3/4】正在检查 IDEA、Toolbox 与教育邮箱证据...'
  $dirs=@(Invoke-Section 'directories' {Get-DirectoryEvidence} @()); $idea=Invoke-Section 'idea' {Get-Idea} ([pscustomobject]@{installations=@();error='采集失败'}); $emailScan=Invoke-Section 'emailScan' {Get-EmailEvidence} ([pscustomobject]@{status='UNKNOWN';domains=@($EduDomains);domainEvidence=@();emailEvidence=@();xmlEvidence=@();credentialManager=@{status='UNKNOWN';entries=@();errors=@('教育邮箱证据采集失败')};credentialFiles=@();configPresent=$false;scanned=0;truncated=$true;errors=@('教育邮箱证据采集失败')}); $trace=@(Invoke-Section 'trace' {Get-Trace} @())
  $class=@((Read-EnvironmentValue User CLASSPATH).value,(Read-EnvironmentValue Machine CLASSPATH).value) -join ';'
  $username=[Environment]::UserName; if ($username.Length) { $username=$username.Substring(0,1)+'***' }
  return [pscustomobject]@{ schemaVersion=2; meta=@{scriptVersion='2.0.0';collectedAt=[DateTime]::UtcNow.ToString('o');windows=[Environment]::OSVersion.VersionString;user=$username;powershell=$PSVersionTable.PSVersion.ToString()}; env=@{user=$snapshot.user;machine=$snapshot.machine;effectiveJavaHome=$effective;classpath=$class;path=($rawPaths -join ';')}; exec=@{java=$j;javac=$c;settings=$settings}; javaProbe=@{home=$probe;candidates=$candidates;whereJava=$whereJava;whereJavac=$whereJavac;runtimeHome=$evidence.runtime;runtimeMatchesHome=(Compare-Path $evidence.runtime $probe.path);compilerMatchesHome=(Compare-Path $evidence.compiler $probe.path);runtimeMajor=(Get-Major $j.output);compilerMajor=(Get-Major $c.output);forwarders=@(@($whereJava+$whereJavac) | Where-Object { Is-Forwarder $_ } | Select-Object -Unique);pathIncludesHome=$includes;diskUnavailable=$diskUnavailable;jreBinExists=($probe.path -and (Test-Path -LiteralPath ($probe.path+'\jre\bin')));archWarning=$(if ($settings.output -match '(?m)^\s*os.arch\s*=\s*(x86|i386)\s*$' -and [Environment]::Is64BitOperatingSystem) {'当前 Java 为 32 位，Windows 为 64 位'} else {$null})}; idea=$idea;jetbrainsDirs=$dirs;jetbraTrace=$trace;emailScan=$emailScan;errors=@() }
}
function Convert-SafeJson($Data) {
  # Never export unfiltered raw Path values from the registry snapshots.
  foreach ($scope in @('user','machine')) { if ($Data.env.$scope.Path.value) { $Data.env.$scope.Path.value=(@([string]$Data.env.$scope.Path.value -split ';' | Where-Object { $_ -match 'java|jdk|jetbrains' }) -join ';') } }
  if ($Data.exec -and $Data.exec.settings) { $Data.exec.settings.output=(@($Data.exec.settings.output -split '\r?\n' | Where-Object { $_ -match '^\s*(java\.home|java\.version|java\.vendor|os\.arch)\s*=' }) -join [Environment]::NewLine) }
  $Data.errors=@($script:Issues.ToArray())
  $json=$Data | ConvertTo-Json -Depth 6 -Compress
  # JSON escapes backslashes: redact the serialized profile prefix as well.
  $profileJson=ConvertTo-Json ([string]$env:USERPROFILE) -Compress
  if ($profileJson.Length -gt 2) { $json=[regex]::Replace($json,[regex]::Escape($profileJson.Substring(1,$profileJson.Length-2)),'%USERPROFILE%','IgnoreCase') }
  return Protect-Text $json
}
function Copy-ClipboardFallback([string]$Json) {
  $old=$OutputEncoding
  try {
    $OutputEncoding=New-Object Text.UTF8Encoding($false)
    $Json | & (Join-Path $env:SystemRoot 'System32\cmd.exe') /d /c 'chcp 65001>nul & clip.exe'
    if ($LASTEXITCODE -ne 0) { throw '备用剪贴板复制失败' }
    $getClipboard=Get-Command Get-Clipboard -ErrorAction SilentlyContinue
    if ($getClipboard -and ((Get-Clipboard -Raw -ErrorAction Stop).TrimEnd([char]13,[char]10) -ne $Json)) { throw '备用剪贴板回读不一致' }
  } finally { $OutputEncoding=$old }
}
function Save-Result($Data,[string]$Directory) {
  $destination=Join-Path $Directory 'result.txt'; $json=Convert-SafeJson $Data
  try { [IO.File]::WriteAllText($destination,$json,(New-Object Text.UTF8Encoding($true))) } catch { Record-Issue 'result.write' $_ }
  try {
    $setClipboard=Get-Command Set-Clipboard -ErrorAction SilentlyContinue
    $getClipboard=Get-Command Get-Clipboard -ErrorAction SilentlyContinue
    if (!$setClipboard -or !$getClipboard) { throw '当前 PowerShell 没有可用的剪贴板命令' }
    Set-Clipboard -Value $json -ErrorAction Stop
    if ((Get-Clipboard -Raw -ErrorAction Stop).TrimEnd([char]13,[char]10) -ne $json) { throw '剪贴板回读不一致' }
  }
  catch {
    Record-Issue 'clipboard.primary' $_; $json=Convert-SafeJson $Data
    try { Copy-ClipboardFallback $json } catch { Record-Issue 'clipboard.fallback' $_ }
  }
  $json=Convert-SafeJson $Data
  try { [IO.File]::WriteAllText($destination,$json,(New-Object Text.UTF8Encoding($true))) } catch { Record-Issue 'result.write.final' $_; Write-Host '结果文件无法保存，请复制下面的 JSON。' }
  Write-Host ('发现完整 JDK：'+@($Data.javaProbe.candidates | Where-Object {$_.valid}).Count+'；IDEA 安装：'+$Data.idea.installations.Count)
  Write-Host '---JAVA_CHECK_JSON_BEGIN---'; Write-Host $json; Write-Host '---JAVA_CHECK_JSON_END---'
  Write-Host '【4/4】完成'
  Write-Host '请回到浏览器，在第 2 步的框里按 Ctrl+V，然后点解析。'
}

try {
  if (!$OutputDirectory) { $OutputDirectory=$PSScriptRoot }
  $data=Collect-Result
  Save-Result $data $OutputDirectory
} catch {
  Record-Issue 'collector.final' $_
  Write-Host '检测没有完成。请确认 ZIP 已完整解压、PowerShell 版本满足要求，然后重试或使用网页手动检查步骤。'
}
Write-Host '按任意键关闭窗口。'
