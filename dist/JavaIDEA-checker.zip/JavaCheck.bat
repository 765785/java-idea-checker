@echo off & title Java Environment Checker
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0JavaCheck.ps1"
pause
